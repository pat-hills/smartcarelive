<?php

session_start();
 



require_once '../../../functions/conndb.php';
require_once '../../../functions/func_search.php';
require_once '../../../functions/func_consulting.php';
require_once '../../../functions/func_common.php'; 


global $connection;
 

$time = "9:45 AM";

 

$headers = 'From:SmartCareHospital<care@smartcarehospital.com>';  

$sql = "SELECT patient_id,id,date_to_be_seen,staff_id,is_sms_sent FROM  tbl_patient_review WHERE is_sms_sent = 'NO' ";
	$result = mysqli_query($connection,$sql);

	if(mysqli_num_rows($result) > 0){

		while ($row = mysqli_fetch_array($result)) {

			$prev_date_b4_review_date = date('Y-m-d', strtotime('-1 day', strtotime($row['date_to_be_seen'])));

			//we need to add another one day to the previous to update it
			$advance_review_date = date('Y-m-d', strtotime('+1 day', strtotime($row['date_to_be_seen'])));
			$current_date = date("Y-m-d");

			if( $prev_date_b4_review_date == $current_date ){

				//getting patient details
			get_pat_email_sms($row['patient_id']); 

           

			$doctor = get_staff_info($row['staff_id']);

        	$dr_fullname =  $doctor['firstName'] . " " . $doctor['otherNames']; 
			$subject = 'Upcoming appointment with Dr. '.$dr_fullname." at ".$time;

			$message = trim("Dear ". strtoupper($_SESSION['fullname'] ). ", \n This is a reminder of your upcoming appointment with Dr. " . $dr_fullname ."
			at SmartCareHospital ". " on " . $row['date_to_be_seen']. " ".$time. " \n Thank you.");
 
			$mail =  mail($_SESSION['email_contact'], $subject, $message, $headers);

			if($mail){
 			//function to update review when sent //“/home/taugscsf/sch2021.smartcarehospital.com”:

			 //php /home/taugscsf/sch2021.smartcarehospital.com/users/consulting/cron_job_notifications/send_review_notifications.php
 
			update_patient_sent_review_notification($row['patient_id'],$advance_review_date,$message,$current_date);
			}
 

			}else{
				echo "Not ready";
				exit();
			}

			
			
		

		}

	}